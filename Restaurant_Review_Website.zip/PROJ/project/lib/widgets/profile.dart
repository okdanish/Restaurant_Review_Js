// import 'package:flutter/material.dart';

// class ProfilePage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Profile'),
//         actions: [
//           IconButton(
//             icon: Icon(Icons.edit),
//             onPressed: () {
//               // Handle edit button press
//             },
//           ),
//           IconButton(
//             icon: Icon(Icons.redeem),
//             onPressed: () {
//               // Handle rewards button press
//             },
//           ),
//         ],
//       ),
//       body: Padding(
//         padding: EdgeInsets.all(20.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: <Widget>[
//             CircleAvatar(
//               radius: 80.0,
//               backgroundImage: AssetImage('assets/profile_picture.jpg'),
//             ),
//             SizedBox(height: 20.0),
//             Text(
//               'John Doe',
//               style: TextStyle(
//                 fontSize: 24.0,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             SizedBox(height: 10.0),
//             Text(
//               'Points: 500',
//               style: TextStyle(fontSize: 16.0),
//             ),
//             SizedBox(height: 20.0),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//               children: <Widget>[
//                 _buildProfileStat('Favorites', '10'),
//                 _buildProfileStat('Challenges\nCompleted', '5'),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildProfileStat(String title, String value) {
//     return Column(
//       children: <Widget>[
//         Text(
//           value,
//           style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
//         ),
//         SizedBox(height: 5.0),
//         Text(
//           title,
//           textAlign: TextAlign.center,
//           style: TextStyle(fontSize: 16.0),
//         ),
//       ],
//     );
//   }
// }

// void main() {
//   runApp(MaterialApp(
//     title: 'Profile Demo',
//     home: ProfilePage(),
//   ));
// }
